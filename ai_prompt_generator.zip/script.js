// 提示词元素数据库
const promptElements = {
    subjects: {
        character: [ // 人物角色
            { zh: "少女", en: "beautiful girl, young woman", category: "character" },
            { zh: "魔法少女", en: "magical girl, anime style", category: "character" },
            { zh: "武士", en: "samurai warrior", category: "character" },
            { zh: "探险家", en: "explorer, adventurer", category: "character" },
            { zh: "街头艺术家", en: "street artist", category: "character" },
            { zh: "古装美人", en: "traditional Chinese beauty", category: "character" },
            { zh: "机械战士", en: "mechanical warrior", category: "character" },
            { zh: "太空旅人", en: "space traveler", category: "character" }
        ],
        fantasy: [ // 奇幻魔法
            { zh: "魔法师", en: "wizard, sorcerer", category: "fantasy" },
            { zh: "精灵", en: "elf, fairy", category: "fantasy" },
            { zh: "龙骑士", en: "dragon rider", category: "fantasy" },
            { zh: "幻想生物", en: "fantasy creature", category: "fantasy" },
            { zh: "独角兽", en: "unicorn", category: "fantasy" },
            { zh: "神秘法师", en: "mystic mage", category: "fantasy" }
        ],
        scifi: [ // 科幻机械
            { zh: "机器人", en: "robot, android", category: "scifi" },
            { zh: "赛博格", en: "cyborg", category: "scifi" },
            { zh: "机甲战士", en: "mecha warrior", category: "scifi" },
            { zh: "未来战士", en: "future soldier", category: "scifi" },
            { zh: "太空战舰", en: "spaceship", category: "scifi" }
        ],
        animal: [ // 生物怪兽
            { zh: "神兽", en: "divine beast", category: "animal" },
            { zh: "巨龙", en: "dragon", category: "animal" },
            { zh: "凤凰", en: "phoenix", category: "animal" },
            { zh: "海怪", en: "sea monster", category: "animal" },
            { zh: "幻兽", en: "mythical creature", category: "animal" }
        ],
        abstract: [ // 抽象概念
            { zh: "时间", en: "concept of time", category: "abstract" },
            { zh: "梦境", en: "dreamscape", category: "abstract" },
            { zh: "情感", en: "emotions", category: "abstract" },
            { zh: "意识", en: "consciousness", category: "abstract" }
        ]
    },
    scenes: [ // 改为数组形式，与实际使用方式匹配
        // 自然风光
        { zh: "瀑布", en: "waterfall", category: "scene" },
        { zh: "山峰", en: "mountain peaks", category: "scene" },
        { zh: "森林", en: "forest", category: "scene" },
        { zh: "海洋", en: "ocean", category: "scene" },
        { zh: "极光", en: "aurora", category: "scene" },
        // 城市建筑
        { zh: "未来都市", en: "futuristic city", category: "scene" },
        { zh: "古代城池", en: "ancient city", category: "scene" },
        { zh: "空中城市", en: "floating city", category: "scene" },
        { zh: "地下城", en: "underground city", category: "scene" },
        // 自然奇观
        { zh: "火山", en: "volcano", category: "scene" },
        { zh: "峡谷", en: "canyon", category: "scene" },
        { zh: "沙漠", en: "desert", category: "scene" },
        { zh: "热带雨林", en: "rainforest", category: "scene" },
        { zh: "冰川", en: "glacier", category: "scene" },
        // 特殊场景
        { zh: "废墟", en: "ruins", category: "scene" },
        { zh: "神秘岛屿", en: "mysterious island", category: "scene" },
        { zh: "花园", en: "garden", category: "scene" },
        { zh: "湖泊", en: "lake", category: "scene" },
        { zh: "悬崖", en: "cliff", category: "scene" },
        { zh: "港口", en: "harbor", category: "scene" }
    ],
    styles: [
        // 艺术风格
        { zh: "赛博朋克", en: "cyberpunk style" },
        { zh: "水彩画", en: "watercolor painting" },
        { zh: "油画", en: "oil painting" },
        { zh: "像素风格", en: "pixel art style" },
        { zh: "水墨画", en: "Chinese ink painting" },
        { zh: "浮世绘", en: "ukiyo-e style" },
        { zh: "未来主义", en: "futuristic style" },
        { zh: "写实风格", en: "realistic style, photorealistic" },
        { zh: "童话风格", en: "fairy tale style, fantasy art" },
        { zh: "蒸汽朋克", en: "steampunk style" },
        { zh: "复古风格", en: "retro style, vintage" },
        { zh: "极简主义", en: "minimalist style" },
        { zh: "印象派", en: "impressionist style" },
        { zh: "超现实主义", en: "surrealist style" },
        { zh: "二次元", en: "anime style" },
        { zh: "哥特风格", en: "gothic style" }
    ],
    effects: [
        // 视觉效果
        { zh: "霓虹灯", en: "neon lights, glowing" },
        { zh: "魔法粒子", en: "magical particles, sparkling" },
        { zh: "光晕效果", en: "light halo, ethereal glow" },
        { zh: "烟雾缭绕", en: "misty, foggy atmosphere" },
        { zh: "闪耀星光", en: "twinkling stars, starlight" },
        { zh: "全息投影", en: "holographic effect" },
        { zh: "彩虹光芒", en: "rainbow light" },
        { zh: "水晶反射", en: "crystal reflections" },
        { zh: "金属质感", en: "metallic texture" },
        { zh: "玻璃折射", en: "glass refraction" },
        { zh: "流光溢彩", en: "iridescent effect" },
        { zh: "闪电效果", en: "lightning effect" },
        { zh: "火焰特效", en: "fire effects" },
        { zh: "水波纹理", en: "water ripples" }
    ],
    time: [
        // 时间
        { zh: "黎明", en: "dawn, sunrise" },
        { zh: "黄昏", en: "sunset, dusk" },
        { zh: "午夜", en: "midnight" },
        { zh: "蓝调时分", en: "blue hour" },
        { zh: "黄金时段", en: "golden hour" }
    ],
    weather: [
        // 天气
        { zh: "雨天", en: "rainy weather" },
        { zh: "雪景", en: "snowy scene" },
        { zh: "雾气", en: "foggy" },
        { zh: "阳光", en: "sunny" },
        { zh: "风暴", en: "storm" }
    ],
    qualities: [
        // 画质和细节
        { zh: "8k超清", en: "8k uhd, highly detailed" },
        { zh: "细节丰富", en: "intricate details, fine details" },
        { zh: "高清晰度", en: "high resolution, sharp focus" },
        { zh: "完美构图", en: "perfect composition" },
        { zh: "光影真实", en: "realistic lighting" },
        { zh: "质感写实", en: "realistic textures" },
        { zh: "超高清渲染", en: "ultra-high definition rendering" },
        { zh: "完美照明", en: "perfect lighting" }
    ],
    additional: [
        // 额外品质
        { zh: "工作室级别", en: "studio quality, professional" },
        { zh: "大师级作品", en: "masterpiece, best quality" },
        { zh: "电影感", en: "cinematic, movie shot" },
        { zh: "艺术感", en: "artistic, fine art" },
        { zh: "史诗级", en: "epic, legendary" },
        { zh: "梦幻感", en: "dreamy, ethereal" },
        { zh: "科幻感", en: "sci-fi atmosphere" },
        { zh: "魔幻感", en: "magical atmosphere" }
    ],
    camera: [
        // 镜头效果
        { zh: "特写镜头", en: "close-up shot" },
        { zh: "全景视角", en: "panoramic view" },
        { zh: "鸟瞰视角", en: "aerial view" },
        { zh: "微距摄影", en: "macro photography" },
        { zh: "景深效果", en: "depth of field" },
        { zh: "广角镜头", en: "wide-angle lens" }
    ],
    regions: [
        // 东亚
        { zh: "中国风", en: "Chinese style", area: "asia" },
        { zh: "日本风", en: "Japanese style", area: "asia" },
        { zh: "韩国风", en: "Korean style", area: "asia" },
        // 欧洲
        { zh: "法国风", en: "French style", area: "europe" },
        { zh: "意大利风", en: "Italian style", area: "europe" },
        { zh: "北欧风", en: "Nordic style", area: "europe" },
        { zh: "英伦风", en: "British style", area: "europe" },
        // 美洲
        { zh: "美国风", en: "American style", area: "america" },
        { zh: "墨西哥风", en: "Mexican style", area: "america" },
        // 其他
        { zh: "中东风", en: "Middle Eastern style", area: "other" },
        { zh: "印度风", en: "Indian style", area: "other" },
        { zh: "东南亚风", en: "Southeast Asian style", area: "other" }
    ],
};

// 添加图标数组
const cardIcons = [
    'fa-wand-magic-sparkles',
    'fa-robot',
    'fa-dragon',
    'fa-hat-wizard',
    'fa-mountain-city',
    'fa-space-awesome',
    'fa-camera-retro',
    'fa-paintbrush',
    'fa-compass',
    'fa-ghost',
    'fa-rocket',
    'fa-staff',
    'fa-galaxy',
    'fa-unicorn'
];

// 添加当前选中的分类变量
let currentCategory = 'all';

// 生成随机提示词卡片
function generatePromptCard(category = 'all') {
    let subject, environment;
    
    if (category === 'scene') {
        subject = getRandomElementByCategory(promptElements.scenes, category);
        environment = null;
    } else {
        subject = getRandomElementByCategory(promptElements.subjects, category);
        environment = getRandomElement(promptElements.scenes);
    }

    const style = getRandomElement(promptElements.styles);
    const effect = getRandomElement(promptElements.effects);
    const time = getRandomElement(promptElements.time);
    const weather = Math.random() > 0.5 ? getRandomElement(promptElements.weather) : null;
    const quality = getRandomElement(promptElements.qualities);
    const additional = getRandomElement(promptElements.additional);
    const camera = Math.random() > 0.5 ? getRandomElement(promptElements.camera) : null;
    const icon = getRandomElement(cardIcons);

    // 随机添加地域元素（30%概率）
    const regionStyle = Math.random() > 0.7 ? getRandomElement(promptElements.regions) : null;

    // 组合提示词
    const elements = [subject];
    if (environment) elements.push(environment);
    if (regionStyle) elements.push(regionStyle);
    elements.push(effect, style, time);
    if (weather) elements.push(weather);
    if (camera) elements.push(camera);
    elements.push(quality, additional);

    const promptEn = elements.map(el => el.en).join(", ");
    const promptZh = elements.map(el => el.zh).join(", ");
    
    // 更新描述文本，场景类型时不包含环境描述
    const description = category === 'scene' 
        ? `这是一幅以${subject.zh}为主题的场景作品。
           ${regionStyle ? '采用' + regionStyle.zh + '，' : ''}
           ${time.zh}时分${weather ? '，' + weather.zh : ''}的氛围下，画面呈现${effect.zh}效果。
           采用${style.zh}风格绘制，${quality.zh}，整体${additional.zh}。
           ${camera ? '使用' + camera.zh + '视角表现。' : ''}`
        : `这是一幅以${subject.zh}为主题，在${environment.zh}场景中的作品。
           ${regionStyle ? '采用' + regionStyle.zh + '，' : ''}
           ${time.zh}时分${weather ? '，' + weather.zh : ''}的氛围下，画面呈现${effect.zh}效果。
           采用${style.zh}风格绘制，${quality.zh}，整体${additional.zh}。
           ${camera ? '使用' + camera.zh + '视角表现。' : ''}`;

    const card = document.createElement('div');
    card.className = 'prompt-card';
    card.innerHTML = `
        <div class="category-label" data-category="${subject.category}">
            ${getCategoryName(subject.category)}
        </div>
        <div class="card-icon">
            <i class="fas ${getCategoryIcon(subject.category)}"></i>
        </div>
        <div class="prompt-content">
            <div class="prompt-text-zh">${promptZh}</div>
            <div class="prompt-text-en">${promptEn}</div>
            <div class="prompt-description">${description.replace(/\s+/g, ' ')}</div>
        </div>
        <div class="button-group">
            <button class="copy-btn" onclick="copyPrompt(this, '${promptEn}')">
                <i class="fas fa-copy"></i> 复制英文
            </button>
            <button class="copy-btn" onclick="copyPrompt(this, '${promptZh}')">
                <i class="fas fa-copy"></i> 复制中文
            </button>
        </div>
    `;

    return card;
}

// 取随机元素
function getRandomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

// 复制提示词功能
function copyPrompt(button, text) {
    navigator.clipboard.writeText(text).then(() => {
        button.classList.add('copied');
        button.innerHTML = '<i class="fas fa-check"></i> 已复制';
        setTimeout(() => {
            button.classList.remove('copied');
            button.innerHTML = '<i class="fas fa-copy"></i> 复制提示词';
        }, 2000);
    });
}

// 生成多个提示词卡片
function generatePromptCards(count = 12, category = 'all') {
    const container = document.getElementById('promptCards');
    container.innerHTML = '';
    for (let i = 0; i < count; i++) {
        container.appendChild(generatePromptCard(category));
    }
}

// 页面加载时生成卡片
document.addEventListener('DOMContentLoaded', () => {
    generatePromptCards(); // 原有的初始化
    initializeOptions(); // 初始化自定义选项
    loadSavedCustomPrompts(); // 加载保存的自定义提示词
    
    // 设置页脚年份
    document.getElementById('currentYear').textContent = new Date().getFullYear();
});

// 点击按钮时生成新的提示词卡片
document.getElementById('generateBtn').addEventListener('click', () => {
    generatePromptCards(12, currentCategory);
});

// 添加分类过滤功能
document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const category = btn.dataset.category;
        
        // 更新按钮状态
        document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // 更新当前分类
        currentCategory = category;
        
        // 重新生成卡片
        generatePromptCards(12, category);
    });
});

// 辅助函数：根据分类获取随机元素
function getRandomElementByCategory(elements, category) {
    if (category === 'all') {
        // 如果是场景数组，直接使用
        if (Array.isArray(elements)) {
            return getRandomElement(elements);
        }
        // 如果是对象，则展平所有类别
        return getRandomElement(Object.values(elements).flat());
    }
    
    // 如是场景数组，直接筛选
    if (Array.isArray(elements)) {
        const categoryElements = elements.filter(item => item.category === category);
        return getRandomElement(categoryElements);
    }
    
    // 如果是对象，则从对应类别中筛选
    const categoryElements = Object.values(elements)
        .flat()
        .filter(item => item.category === category);
        
    if (categoryElements.length === 0) {
        return getRandomElement(Object.values(elements).flat());
    }
    
    return getRandomElement(categoryElements);
}

// 获取分类中文名称
function getCategoryName(category) {
    const categoryNames = {
        'character': '人物角色',
        'scene': '场景风光',
        'fantasy': '奇幻魔法',
        'scifi': '科幻机械',
        'animal': '生物怪兽',
        'abstract': '抽象概念'
    };
    return categoryNames[category] || '其他';
}

// 添加获取分类图标的函数
function getCategoryIcon(category) {
    const categoryIcons = {
        'character': 'fa-user',
        'scene': 'fa-mountain',
        'fantasy': 'fa-hat-wizard',
        'scifi': 'fa-robot',
        'animal': 'fa-dragon',
        'abstract': 'fa-brain'
    };
    return categoryIcons[category] || 'fa-star';
}

// 保存用户自定义提示词的键名
const CUSTOM_PROMPTS_KEY = 'customPrompts';

// 标签页切换功能
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        // 更新按钮状态
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // 更新内容显示
        const tabId = btn.dataset.tab;
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabId + 'Tab').classList.add('active');
    });
});

// 初始化选项组
function initializeOptions() {
    // 初始化主体选项
    const subjectOptions = document.getElementById('subjectOptions');
    Object.values(promptElements.subjects).flat().forEach(subject => {
        addOption(subjectOptions, subject, 'subject');
    });

    // 初始化场景选项
    const sceneOptions = document.getElementById('sceneOptions');
    promptElements.scenes.forEach(scene => {
        addOption(sceneOptions, scene, 'scene');
    });

    // 初始化其他选项
    initializeOptionGroup('styleOptions', promptElements.styles, 'style');
    initializeOptionGroup('effectOptions', promptElements.effects, 'effect');
    initializeOptionGroup('timeOptions', promptElements.time, 'time');
    initializeOptionGroup('weatherOptions', promptElements.weather, 'weather');
    initializeOptionGroup('qualityOptions', promptElements.qualities, 'quality');
    initializeOptionGroup('additionalOptions', promptElements.additional, 'additional');
    initializeOptionGroup('cameraOptions', promptElements.camera, 'camera');

    // 初始化地域选项
    const regionOptions = document.getElementById('regionOptions');
    promptElements.regions.forEach(region => {
        addOption(regionOptions, region, 'region');
    });
}

// 初始化选项组的辅助函数
function initializeOptionGroup(elementId, options, groupName) {
    const container = document.getElementById(elementId);
    options.forEach(option => {
        addOption(container, option, groupName);
    });
}

// 添加选项的辅助函数
function addOption(container, option, groupName) {
    const btn = document.createElement('button');
    btn.className = 'option-btn';
    btn.dataset.group = groupName;
    btn.dataset.en = option.en;
    btn.dataset.zh = option.zh;
    btn.innerHTML = option.zh;
    
    btn.addEventListener('click', () => {
        // 同组选项互斥
        container.querySelectorAll('.option-btn').forEach(b => {
            if (b !== btn) b.classList.remove('selected');
        });
        btn.classList.toggle('selected');
    });
    
    container.appendChild(btn);
}

// 创建自定义提示词
document.getElementById('createCustomPrompt').addEventListener('click', () => {
    const selectedOptions = {
        subject: getSelectedOption('subject'),
        scene: getSelectedOption('scene'),
        style: getSelectedOption('style'),
        effect: getSelectedOption('effect'),
        time: getSelectedOption('time'),
        weather: getSelectedOption('weather'),
        quality: getSelectedOption('quality'),
        additional: getSelectedOption('additional'),
        camera: getSelectedOption('camera')
    };

    // 检查必要选项是否已选择
    if (!selectedOptions.subject || !selectedOptions.scene) {
        alert('请至少选择主体和场景！');
        return;
    }

    // 创建提示词对象
    const prompt = createPromptObject(selectedOptions);
    
    // 保存到���地存储
    saveCustomPrompt(prompt);
    
    // 显示新创建的提示词卡片
    displayCustomPromptCard(prompt);
    
    // 清除所有选择
    clearAllSelections();
});

// 获取选中的选项
function getSelectedOption(groupName) {
    const selected = document.querySelector(`.option-btn[data-group="${groupName}"].selected`);
    return selected ? { zh: selected.dataset.zh, en: selected.dataset.en } : null;
}

// 创建提示词对象
function createPromptObject(options) {
    // 添加地域选项
    const region = getSelectedOption('region');
    if (region) {
        options.region = region;
    }

    const elements = Object.values(options).filter(Boolean);
    
    // 获取用户自定义输入
    const customZh = document.getElementById('customZh').value.trim();
    const customEn = document.getElementById('customEn').value.trim();
    
    // 组合提示词，优先使用自定义输入
    let promptZh = elements.map(el => el.zh).join(", ");
    let promptEn = elements.map(el => el.en).join(", ");
    
    if (customZh) {
        promptZh = customZh + ", " + promptZh;
    }
    
    if (customEn) {
        promptEn = customEn + ", " + promptEn;
    }
    
    return {
        id: Date.now().toString(),
        promptEn,
        promptZh,
        elements: options,
        customZh,
        customEn
    };
}

// 保存自定义提示词到本地存储
function saveCustomPrompt(prompt) {
    const savedPrompts = JSON.parse(localStorage.getItem(CUSTOM_PROMPTS_KEY) || '[]');
    savedPrompts.push(prompt);
    localStorage.setItem(CUSTOM_PROMPTS_KEY, JSON.stringify(savedPrompts));
}

// 显示自定义提示词卡片
function displayCustomPromptCard(prompt) {
    const container = document.getElementById('customPromptCards');
    const card = createCustomPromptCard(prompt);
    container.insertBefore(card, container.firstChild);
}

// 创建自定义提示词卡片
function createCustomPromptCard(prompt) {
    const card = document.createElement('div');
    card.className = 'prompt-card custom-card';
    card.dataset.id = prompt.id;
    
    card.innerHTML = `
        <div class="card-icon">
            <i class="fas fa-magic"></i>
        </div>
        <div class="prompt-content">
            <div class="prompt-text-zh">${prompt.promptZh}</div>
            <div class="prompt-text-en">${prompt.promptEn}</div>
        </div>
        <div class="button-group">
            <button class="copy-btn" onclick="copyPrompt(this, '${prompt.promptEn}')">
                <i class="fas fa-copy"></i> 复制英文
            </button>
            <button class="copy-btn" onclick="copyPrompt(this, '${prompt.promptZh}')">
                <i class="fas fa-copy"></i> 复制中文
            </button>
            <button class="delete-btn" onclick="deleteCustomPrompt('${prompt.id}')">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    return card;
}

// 删除自定义提示词
function deleteCustomPrompt(id) {
    if (!confirm('确定要删除这个提示词吗？')) return;
    
    // 从本地存储中删除
    const savedPrompts = JSON.parse(localStorage.getItem(CUSTOM_PROMPTS_KEY) || '[]');
    const updatedPrompts = savedPrompts.filter(p => p.id !== id);
    localStorage.setItem(CUSTOM_PROMPTS_KEY, JSON.stringify(updatedPrompts));
    
    // 从DOM中删除
    const card = document.querySelector(`.prompt-card[data-id="${id}"]`);
    if (card) {
        card.remove();
    }
}

// 清除所有选择
function clearAllSelections() {
    document.querySelectorAll('.option-btn.selected').forEach(btn => {
        btn.classList.remove('selected');
    });
    
    // 清除输入框
    document.getElementById('customZh').value = '';
    document.getElementById('customEn').value = '';
}

// 加载保存的自定义提示词
function loadSavedCustomPrompts() {
    const savedPrompts = JSON.parse(localStorage.getItem(CUSTOM_PROMPTS_KEY) || '[]');
    const container = document.getElementById('customPromptCards');
    container.innerHTML = '';
    savedPrompts.forEach(prompt => {
        container.appendChild(createCustomPromptCard(prompt));
    });
}
  